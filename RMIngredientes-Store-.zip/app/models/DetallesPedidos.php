<?php

class DetallesPedidos extends Eloquent
{
	protected $table = "detalle_pedidos";


}